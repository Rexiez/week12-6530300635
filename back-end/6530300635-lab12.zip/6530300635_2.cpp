#include <iostream>
using namespace std;

int arr[11];
int length;
int heapsize = 10;

void heapify(int arr[], int i, int heapsize) {
    int largest = i;
    int left = 2 * i;
    int right = 2 * i + 1;

    if (left <= heapsize && arr[left] > arr[largest]) {
        largest = left;
    }

    if (right <= heapsize && arr[right] > arr[largest]) {
        largest = right;
    }

    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, largest, heapsize);
    }
}

void build_heap(int arr[], int heapsize) {
    length = heapsize;

    for (int i = length / 2; i >= 1; i--) {
        heapify(arr, i, heapsize);
    }
}

void heap_sort(int arr[], int heapsize) {
    build_heap(arr, heapsize);

    cout << "\nHeap Sort" << endl;

    for (int i = 1; i <= heapsize; i++) {
        swap(arr[1], arr[heapsize - i + 1]);
        cout << "#" << i << ": ";
        for (int j = 1; j <= length; j++) {
            cout << arr[j] << " ";
        }
        cout << endl;
        heapify(arr, 1, heapsize - i);
    }
}

int main() {
    cout << "Input Array: ";
    for (int i = 1; i <= heapsize; i++) {
        cin >> arr[i];
    }

    build_heap(arr, heapsize);

    cout << "Heap: ";
    for (int i = 1; i <= heapsize; i++) {
        cout << arr[i] << " ";
    }

    heap_sort(arr, heapsize);

    return 0;
}
