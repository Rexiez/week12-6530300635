#include <iostream>
using namespace std;

int arr[11];
int length;
int heapsize = 10;

void heapify(int arr[], int i) {
    int largest = i;
    int left = 2 * i;
    int right = 2 * i + 1;

    if (left <= heapsize && arr[left] > arr[largest]) {
        largest = left;
    }

    if (right <= heapsize && arr[right] > arr[largest]) {
        largest = right;
    }

    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, largest);
    }
}

void build_heap(int arr[], int heapsize) {
    length = heapsize;

    for (int i = length / 2; i >= 1; i--) {
        heapify(arr, i);
    }
}

int main() {
    cout << "Input Array: ";
    for (int i = 1; i <= heapsize; i++) {
        cin >> arr[i];
    }

    build_heap(arr, heapsize);

    cout << "Heap: ";
    for (int i = 1; i <= heapsize; i++) {
        cout << arr[i] << " ";
    }

    return 0;
}
