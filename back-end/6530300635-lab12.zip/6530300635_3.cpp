#include <iostream>
using namespace std;

int heapsize = 10;
int arr[11];
int length;

void heapify(int arr[], int i, int heapsize) {
    int largest = i;
    int left = 2 * i;
    int right = 2 * i + 1;

    if (left <= heapsize && arr[left] > arr[largest]) {
        largest = left;
    }

    if (right <= heapsize && arr[right] > arr[largest]) {
        largest = right;
    }

    if (largest != i) {
        swap(arr[i], arr[largest]);
        heapify(arr, largest, heapsize);
    }
}

void build_heap(int arr[], int heapsize) {
    length = heapsize;

    for (int i = length / 2; i >= 1; i--) {
        heapify(arr, i, heapsize);
    }
}

void heap_sort(int arr[], int heapsize) {
    build_heap(arr, heapsize);

    cout << "\nHeap Sort" << endl;

    for (int i = 1; i <= heapsize; i++) {
        swap(arr[1], arr[heapsize - i + 1]);
        heapify(arr, 1, heapsize - i);
    }
}

void heap_insert(int arr[], int key) {
    heapsize = heapsize + 1;
    int i;
    i = heapsize;
    while (i > 1 && arr[i / 2] < key) {
        arr[i] = arr[i / 2];
        i = i / 2;}
        arr[i] = key;
    
}

int heap_extract_max(int arr[]) {
    int max = arr[1];
    arr[1] = arr[heapsize];
    heapsize = heapsize - 1;
    heapify(arr, 1, heapsize);
    return max;
}

void printHeap() {
    cout << "Heap: ";
    for (int i = 1; i <= heapsize; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

int main() {
    int choose;
    int inputValue;
    bool is_running = true;
    int extracted; 

    while (is_running) {
        cout << "========================" << endl;
        cout << "        MENU    " << endl;
        cout << "========================" << endl;
        cout << "1. Input Array" << endl;
        cout << "2. Print Heap" << endl;
        cout << "3. Insert Queue" << endl;
        cout << "4. Service" << endl;
        cout << "5. Exit" << endl;
        cout << "Please choose > ";
        cin >> choose;

        switch (choose) {
            case 1:
                cout << "Input Array: "; 
                for (int i = 1; i <= heapsize; i++) {
                    cin >> arr[i];
                }
                build_heap(arr, heapsize);
                break;
            case 2:
                cout << "Heap: ";
                printHeap();
                break;
            case 3:
                cout << "Insert: ";
                cin >> inputValue;
                heap_insert(arr, inputValue);
                build_heap(arr, heapsize); 
                printHeap();
                break;
            case 4:
                cout << "Service: ";
                extracted = heap_extract_max(arr);
                cout << extracted << endl;
                build_heap(arr, heapsize);
                printHeap();
                break;
            case 5:
                is_running = false;
                break;
            default:
                cout << "Invalid choice. Please choose again." << endl;
        }
    }

    return 0;
}
